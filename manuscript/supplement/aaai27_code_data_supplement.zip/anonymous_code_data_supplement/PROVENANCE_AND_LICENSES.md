# Provenance and review-use notice

The small committed fixtures are derived analysis fixtures from archived
HotpotQA-style and HumanEvalPack-style workflow outputs. They are included
only to exercise parser paths and structural invariants and are explicitly not
population-representative. Full historical raw traces and third-party source
repositories are not redistributed.

This anonymous package is supplied for peer review. Final public-release
licenses and attribution notices will accompany the de-anonymized artifact.
