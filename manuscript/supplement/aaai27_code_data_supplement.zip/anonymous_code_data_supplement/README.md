# Anonymous Code and Data Supplement

This archive contains the paper's review-shareable analysis code, focused
fixtures, machine-readable results, and provenance ledgers. It contains no new
model experiment and does not run a studied agent system.

Reproducibility boundary:

- Fixture tests reproduce code paths and structural invariants.
- `manuscript/stage2_5/descriptive_counts.json` records the independently
  recomputed aggregate cells and the hashes of the external raw inputs.
- Full aggregate reproduction requires those external inputs at exactly the
  recorded hashes; they are not distributed in this archive.
- The frozen historical C6 files are retained for provenance. The manuscript
  uses the semantic corrections in `manuscript/stage2_5/` for its displayed
  Table 1 document-pair cells.

Useful commands from the unpacked archive root:

    python3 gates/C3/v2_1/test_gate_v2_1.py
    python3 gates/C6/test_gate.py
    python3 audits/selective_consumption/test_audit.py
    python3 experiments/actual_skip_calibration/test_d0.py
    python3 manuscript/stage2_5/test_recompute_descriptive_counts.py

The last command always tests the corrected nested-title parser. Set
`AAAI27_HISTORICAL_ROOT` and `AAAI27_ROUTE_A_PLUS_ROOT` to SHA-matching input
trees to enable its full aggregate recount.
